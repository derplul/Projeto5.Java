package controller;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CadastroServlet
 */
@WebServlet("/CadastroServlet")
public class CadastroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastroServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
			// Defina o caminho do banco de dados SQLite
		    final String DB_URL = "jdbc:sqlite:C:\\Users\\Aluno\\Documents\\lul\\database.db";
			
		    // Obtenha os parâmetros do formulário
		    String username = request.getParameter("username");
		    String email = request.getParameter("email");
		    String password = request.getParameter("password");
		    String passwordConfirmation = request.getParameter("passwordConfirmation");

		    // Validação básica de senha
		    if (!password.equals(passwordConfirmation)) {
		        response.getWriter().println("Erro: As senhas não correspondem!");
		        return;
		    }

		    // Insira os dados no banco de dados
		    try (Connection connection = DriverManager.getConnection(DB_URL)) {
		        String sql = "INSERT INTO usuarios (username, email, password) VALUES (?, ?, ?)";
		        try (PreparedStatement statement = connection.prepareStatement(sql)) {
		            statement.setString(1, username);
		            statement.setString(2, email);
		            statement.setString(3, password);
		            int rowsInserted = statement.executeUpdate();

		            if (rowsInserted > 0) {
		                response.getWriter().println("Cadastro realizado com sucesso!");
		            } else {
		                response.getWriter().println("Erro ao cadastrar usuário.");
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		        response.getWriter().println("Erro ao conectar com o banco de dados.");
		    }
		}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
