package controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
		// TODO Auto-generated method stub


		    // URL do banco de dados SQLite
		    private static final String DB_URL = "jdbc:sqlite:C:\\Users\\Aluno\\Documents\\lul\\database.db";

		    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        // Obtenha os parâmetros do formulário
		        String username = request.getParameter("username");
		        String password = request.getParameter("password");

		        // Valide o login
		        try (Connection connection = DriverManager.getConnection(DB_URL)) {
		            String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
		            try (PreparedStatement statement = connection.prepareStatement(sql)) {
		                statement.setString(1, username);
		                statement.setString(2, password);

		                try (ResultSet resultSet = statement.executeQuery()) {
		                    if (resultSet.next()) {
		                        // Login bem-sucedido
		                        response.getWriter().println("Login realizado com sucesso! Bem-vindo, " + username + ".");
		                    } else {
		                        // Credenciais inválidas
		                        response.getWriter().println("Erro: Nome de usuário ou senha incorretos.");
		                    }
		                }
		            }
		        } catch (SQLException e) {
		            e.printStackTrace();
		            response.getWriter().println("Erro ao conectar com o banco de dados.");
		        }
		    }
	}